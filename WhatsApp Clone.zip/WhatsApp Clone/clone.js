var area =document.getElementById("text");
area.addEventListener("keyup", function() {
         document.getElementById("send").style.visibility ="visible";
         document.getElementById("close").style.visibility ="hidden";
      });
    
      document.getElementById("send").style.visibility ="hidden";
         document.getElementById("close").stylevisibility ="visible";
  
      var color = ["1","2","3","4","a","b","c","d","e","f","5","6","7","8","9","0","a","b","c","d","e","f","g","h","o","ta","1","2","3","a","b","c","d","e","f","4","5","6","a","b","c","d","e","f","7","1","2","3","4","5","6","7","a","b","c","d","e","f",,"a","b","c","d","e","f","1","2","3","4","5","6","7","a","b","c","d","e","f","1","2","3","4","5","6","7","g"];
var color1 = ["1","2","3","4","a","b","c","d","e","f","5","6","7","8","9","0","a","b","c","d","e","f","g","h","o","ta","1","2","3","a","b","c","d","e","f","4","5","6","a","b","c","d","e","f","7","1","2","3","4","5","6","7","a","b","c","d","e","f",,"a","b","c","d","e","f","1","2","3","4","5","6","7","a","b","c","d","e","f","1","2","3","4","5","6","7"];

    
    
        
        if(color.length >0){
        var math=  Math.floor(Math.random() * color.length);
        var math1=  Math.floor(Math.random() * color1.length);
       var cl= color[math1] +  color[math] + color[math1] +   color[math1]  + color[math]  + color[math1]  ;
       var tag = "#";
       var co = tag + cl; 
       document.getElementById("text").style.backgroundColor= co;
       
       
      }
      
      
      send.onclick = function() {
        var value = area.value;
       document.getElementById("results").style.backgroundColor= co;
       
 document.getElementById("results").innerHTML=value;
      };
      document.getElementById("send").style.visibility ="hidden";